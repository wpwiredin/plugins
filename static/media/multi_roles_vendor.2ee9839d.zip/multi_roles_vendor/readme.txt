=== Plugin Name ===
Contributors: wpwiredin
Donate link: https://wpwiredin.github.io/plugins/
Tags: WooCommerce, MultiVendor, Marketplace, Users, User Roles, Registration, Login
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

# Requirements

- You have to have WooCommerce installed and activated
- You have to have WCPM installed and activated 
- You have to have a User Login/Registration plugin installed, or custom Login/Registration page setup

# How the Plugin Works

Just activate the plugin and whenever a User registers on your multi-vendor site, they will be assigned a vendor role

# Alterations/Editing

You may change the user role in the plugin to any WCMP roles, like pending vendor etc.

# Versions and Pre-Realease

- This is minimal pre-release of the plugin which only includes support for WCMP, we will release a more production friendly version in due time. 

Enjoy!!!